class Cat < ApplicationRecord
  include Toyable
end
