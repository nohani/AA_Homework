require 'set'

class GraphNode

    attr_accessor :val, :neighbors

    def initialize(value)
        @value
        @neighbors = []
    end

end

def bfs(starting_node, target_value)
    visited = Set.new()
    queue = [starting_node]

    until queue.empty?
        popped_off = queue.shift
        unless visited.include?(popped_off)
            if popped_off.val == target_value
                return popped_off.val
            else
                visited.add(popped_off)
                queue += popped_off.neighbors
            end
        end
    end
nil
end
